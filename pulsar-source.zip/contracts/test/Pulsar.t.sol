// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import "../src/Pulsar.sol";
import "../src/PulsarStaking.sol";

contract PulsarTest is Test {
    Pulsar token;
    PulsarStaking staking;

    address owner = address(this);
    address treasury = makeAddr("treasury");
    address liquidity = makeAddr("liquidity");
    address team = makeAddr("team");
    address alice = makeAddr("alice");
    address bob = makeAddr("bob");
    address pair = makeAddr("pair");

    function setUp() public {
        token = new Pulsar(treasury, liquidity, team);
        staking = new PulsarStaking(address(token));

        token.setAutomatedMarketMakerPair(pair, true);
        token.enableTrading();
        token.setExcludedFromFees(alice, true);
        token.setExcludedFromFees(bob, true);
        token.setExcludedFromLimits(alice, true);
        token.setExcludedFromLimits(bob, true);

        // fund alice & bob for tests
        token.transfer(alice, 1_000_000 ether);
        token.transfer(bob, 1_000_000 ether);
    }

    // ------------------------------------------------------------------
    // Token
    // ------------------------------------------------------------------

    function test_SupplyIsFixed() public view {
        assertEq(token.totalSupply(), 1_000_000_000 ether);
    }

    function test_CannotMint() public {
        // there is no external mint function; balance increase can only come from
        // constructor mint. Verify no mint selector exists.
        (bool ok,) = address(token).call(abi.encodeWithSignature("mint(address,uint256)", alice, 1));
        assertFalse(ok);
    }

    function test_BurnReducesSupply() public {
        uint256 before = token.totalSupply();
        vm.startPrank(alice);
        token.burn(1000 ether);
        vm.stopPrank();
        assertEq(token.totalSupply(), before - 1000 ether);
    }

    function test_BuyTaxApplied() public {
        // pair -> alice : simulate buy (alice is NOT fee-excluded for this test)
        token.setExcludedFromFees(alice, false);

        uint256 amt = 100 ether;
        vm.startPrank(pair);
        token.transfer(alice, amt);
        vm.stopPrank();

        // buyTax 2% -> 2 ether split: 50% treasury (1e), 25% liq (0.5e), 25% burn (0.5e)
        assertEq(token.balanceOf(alice), 98 ether);
        assertEq(token.balanceOf(treasury), 1 ether);
        assertEq(token.balanceOf(liquidity), 0.5 ether);
    }

    function test_SellTaxApplied() public {
        token.setExcludedFromFees(alice, false);

        // first credit alice some tokens from pair (so she has non-zero balance)
        vm.startPrank(pair);
        token.transfer(alice, 100 ether);
        vm.stopPrank();

        // now alice -> pair (sell) 50 tokens
        uint256 balBefore = token.balanceOf(alice);
        vm.startPrank(alice);
        token.transfer(pair, 50 ether);
        vm.stopPrank();

        // alice sent 50, received 0; pair received 49 (after 2% sell tax)
        // tax split: 25e (0.5 ether) burn, 25e (0.5 ether) liq, 50e (1 ether) treasury
        assertEq(token.balanceOf(pair), 49 ether);
        assertEq(token.balanceOf(alice), balBefore - 50 ether);
    }

    function test_TaxCappedAt5Percent() public {
        token.setBuyTax(500); // 5%
        token.setSellTax(500);

        // above cap reverts
        vm.expectRevert();
        token.setBuyTax(501);
        vm.expectRevert();
        token.setSellTax(501);
    }

    function test_TaxReducibleToZero() public {
        token.setBuyTax(0);
        token.setSellTax(0);
        assertEq(token.buyTaxBps(), 0);
        assertEq(token.sellTaxBps(), 0);
    }

    function test_MaxTxEnforced() public {
        // maxTx default = 5% of supply = 50,000,000 ether
        uint256 tooMuch = token.maxTxAmount() + 1;
        vm.startPrank(alice);
        vm.expectRevert();
        token.transfer(bob, tooMuch);
        vm.stopPrank();
    }

    function test_MaxWalletEnforced() public {
        uint256 maxWallet = token.maxWalletAmount();
        // alice already has 1,000,000 which is below maxWallet (50M).
        // Send alice more so she'd exceed if not exempt; toggle her limit exemption off.
        token.setExcludedFromLimits(alice, false);

        // bring alice up to maxWallet - 1, then try to push past
        token.transfer(alice, maxWallet - token.balanceOf(alice) - 1);

        vm.startPrank(alice);
        vm.expectRevert();
        token.transfer(bob, maxWallet); // would push bob > maxWallet
        vm.stopPrank();
    }

    function test_RemoveLimitsDisablesCaps() public {
        token.removeLimits();
        assertFalse(token.limitsInEffect());
        assertEq(token.maxTxAmount(), token.totalSupply());
    }

    function test_TaxSharesMustSumTo10000() public {
        vm.expectRevert();
        token.setTaxShares(5000, 2500, 2499); // sums to 9999
        token.setTaxShares(5000, 2500, 2500); // ok
    }

    function test_TradingEnabledOnce() public {
        // already enabled in setUp
        vm.expectRevert();
        token.enableTrading();
    }

    function test_OnlyOwnerCanSetTax() public {
        vm.startPrank(alice);
        vm.expectRevert();
        token.setBuyTax(100);
        vm.stopPrank();
    }

    // ------------------------------------------------------------------
    // Staking
    // ------------------------------------------------------------------

    function test_StakeAndEarn() public {
        // fund staking contract with rewards
        token.setExcludedFromFees(address(staking), true);
        token.setExcludedFromLimits(address(staking), true);

        // owner gives staking contract a reward pool of 1000 tokens, emitted over 30 days
        token.transfer(address(staking), 1000 ether);
        staking.topUpRewards(1000 ether);

        // alice stakes 100
        vm.startPrank(alice);
        token.approve(address(staking), type(uint256).max);
        staking.stake(100 ether);
        vm.stopPrank();

        // warp 15 days (half the reward period)
        vm.warp(block.timestamp + 15 days);

        uint256 earnedAlice = staking.earned(alice);
        // 500 tokens / 30 days * 15 days ~= 250 (alice is sole staker so earns all)
        assertApproxEqAbs(earnedAlice, 250 ether, 1e15);
    }

    function test_UnstakeReturnsPrincipal() public {
        token.transfer(address(staking), 1000 ether);
        staking.topUpRewards(1000 ether);

        vm.startPrank(alice);
        token.approve(address(staking), type(uint256).max);
        staking.stake(100 ether);
        uint256 before = token.balanceOf(alice);
        staking.unstake(100 ether);
        uint256 after_ = token.balanceOf(alice);
        vm.stopPrank();

        assertEq(after_ - before, 100 ether);
    }

    function test_ClaimPaysRewards() public {
        token.transfer(address(staking), 1000 ether);
        staking.topUpRewards(1000 ether);

        vm.startPrank(alice);
        token.approve(address(staking), type(uint256).max);
        staking.stake(100 ether);
        vm.warp(block.timestamp + 30 days);
        uint256 before = token.balanceOf(alice);
        staking.claim();
        uint256 after_ = token.balanceOf(alice);
        vm.stopPrank();

        // alice is sole staker, full 1000 reward pool emitted over 30 days
        assertApproxEqAbs(after_ - before, 1000 ether, 1e15);
    }

    function test_OwnerCannotSeizeStakedPrincipal() public {
        // owner should NOT be able to drain user staked tokens via recoverERC20
        vm.startPrank(alice);
        token.approve(address(staking), type(uint256).max);
        staking.stake(100 ether);
        vm.stopPrank();

        // available = total balance - totalStaked = 0
        vm.expectRevert();
        staking.recoverERC20(address(token), owner, 1);
    }
}
